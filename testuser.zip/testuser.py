import getpass
username = getpass.getuser()
print(username)